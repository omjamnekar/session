package com.example.kotline_input_project

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {

    lateinit var  textOutput: TextView
    lateinit var   textInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textInput = findViewById(R.id.datainput)
        textOutput = findViewById(R.id.dataoutput)
    }
    fun buttonClicked(view :View?){
        textOutput.text =textInput.text.toString();
    }
}